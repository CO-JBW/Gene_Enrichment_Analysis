import json

import pandas as pd
import requests
from gprofiler import GProfiler


class Enrich:
    """Base class for gene set enrichment analysis results."""

    def __init__(self, gene_list, library):
        self.gene_list = gene_list
        self.library = library
        self._results = None

    @property
    def results(self):
        return self._results

    @results.setter
    def results(self, value):
        self._results = value

    def to_dataframe(self):
        """Return the enrichment results as a pandas dataframe."""
        return pd.DataFrame(
            {
                "rank": [result["rank"] for result in self.results],
                "term": [result["term"] for result in self.results],
                "overlap": [result["overlap"] for result in self.results],
                "p-value": [result["p-value"] for result in self.results],
                "fdr": [result["fdr"] for result in self.results],
            }
        )

    def to_json(self):
        """Return the enrichment results as a JSON string."""
        return json.dumps(self.results)

    def to_html(self):
        """Return the enrichment results as an HTML page."""
        return self.to_dataframe().to_html()

    def to_tsv(self):
        """Return the enrichment results as a TSV spreadsheet."""
        return self.to_dataframe().to_csv(sep="\t")


class Gprofiler(Enrich):
    """Class for gene set enrichment analysis using GProfiler."""

    def __init__(self, gene_list, library):
        super().__init__(gene_list, library)
        match library:
            case "go_bp":
                self.library = "GO:BP"
            case "go_cc":
                self.library = "GO:CC"
            case "go_mf":
                self.library = "GO:MF"
        gp = GProfiler(return_dataframe=False)
        results = gp.profile(
            organism="hsapiens",
            query=gene_list,
            sources=[self.library],
            significance_threshold_method="fdr",
        )
        results = [
            {
                "term": f'{result["name"]} ({result["native"]})',
                "overlap": f'{result["intersection_size"]}/{result["term_size"]}',
                "p-value": result["p_value"],
                "fdr": result["significant"],
            }
            for result in results
        ]
        self.results = [
            {"rank": i, **r}
            for i, r in enumerate(sorted(results, key=lambda r: r["p-value"]))
        ]
        return


class Panther(Enrich):
    def __init__(self, gene_list, library, organism="9606", go_filters=None):
        super().__init__(gene_list, library)
        match library:
            case "go_bp":
                self.library = "biological_process"
            case "go_cc":
                self.library = "cellular_component"
            case "go_mf":
                self.library = "molecular_function"
        PANTHER_URL = "https://pantherdb.org/services/oai/pantherdb"
        try:
            response = requests.get(f"{PANTHER_URL}/supportedannotdatasets")
            response.raise_for_status()
        except requests.exceptions.RequestException as e:
            raise Exception("Error connecting to PantherDB: " + str(e))
        annot_data_set = [
            obj["id"]
            for obj in response.json()["search"]["annotation_data_sets"][
                "annotation_data_type"
            ]
            if obj["label"] == self.library
        ]
        if not annot_data_set:
            raise Exception(f"Annotation type {self.library} not found in PantherDB")
        try:
            response = requests.post(
                f"{PANTHER_URL}/enrich/overrep?geneInputList={','.join(gene_list)}&organism={organism}&annotDataSet={annot_data_set[0]}"
            )
            response.raise_for_status()
            results = response.json()["results"]["result"]
        except requests.exceptions.RequestException as e:
            raise Exception(
                "Error fetching enrichment results from PantherDB: " + str(e)
            )

        if go_filters:
            results = [obj for obj in results if obj["term"]["label"] in go_filters]

        results = [
            {
                "rank": i,
                "term": f'{result["term"].get("label", "")} ({result["term"].get("id", "")})',
                "overlap": f'{result["number_in_list"]}/{result["number_in_reference"]}',
                "p-value": result["pValue"],
                "fdr": result["fdr"],
            }
            for i, result in enumerate(sorted(results, key=lambda r: r["pValue"]))
        ]
        self.results = [
            {"rank": i, **r}
            for i, r in enumerate(sorted(results, key=lambda r: r["p-value"]))
        ]
        return
