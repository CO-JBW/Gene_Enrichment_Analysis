"""Gene Enrichment Analysis Streamlit app."""
from __future__ import annotations

import re
from io import StringIO
from math import log10
from pathlib import Path

import pandas as pd
import plotly.express as px
import streamlit as st
from PIL import Image

from enrichment.enrich import Gprofiler, Panther
from plots import render_ma, render_volcano

UPLOAD_FOLDER = "../scratch"
HGNC_PATTERN = r"^(?:[a-zA-Z][a-zA-Z0-9_-]{0,19}\n?)+$"
REQUIRED_CSV_COLS = {"gene", "logfc", "ave_expr", "p_value", "adj_p_value", "comparison"}
_EMPTY_TAB = (
    "This tab requires a structured CSV/TSV input with columns: "
    "`gene`, `logfc`, `ave_expr`, `p_value`, `adj_p_value`, `comparison`. "
    "It is empty when only a plain gene list is provided."
)

st.set_page_config(
    page_title="Enrichment Analysis", layout="wide", initial_sidebar_state="expanded"
)


# ── Helpers ────────────────────────────────────────────────────────────────

def render_results(gene_list: str, go_library: str, method) -> None:
    """Run enrichment and display results table + bar chart."""
    with st.spinner("Calculating enrichment"):
        result = method(gene_list, go_library).to_dataframe().head(10)
    result = result.set_index("rank")
    st.dataframe(result, use_container_width=True)
    bar = result[["term", "p-value"]].copy()
    bar.loc[:, "p-value"] = bar["p-value"].apply(lambda x: -1 * log10(x))
    bar = bar.sort_values("p-value")
    bar.columns = ["term", "-log10(p-value)"]
    st.plotly_chart(
        px.bar(bar, x="-log10(p-value)", y="term", orientation="h"),
        use_container_width=True,
    )


def input_example() -> None:
    st.session_state.text_input = open("static/example_gene_list.txt").read()


def on_selectbox_change() -> None:
    """Clear the file uploader (by remounting) when a dropdown option is chosen."""
    if st.session_state.capsule_sel != "Select ...":
        st.session_state.uploader_counter += 1


def on_file_uploader_change() -> None:
    """Reset the dropdown to default when a new file is uploaded."""
    key = f"file_uploader_{st.session_state.uploader_counter}"
    if st.session_state.get(key) is not None:
        st.session_state.capsule_sel = "Select ..."


def try_parse_structured_csv(
    content: str, filename: str
) -> tuple[str, pd.DataFrame | None]:
    """Parse file content. Return (newline-separated gene list, DataFrame or None).

    DataFrame is non-None only when all REQUIRED_CSV_COLS are detected.
    Plain .txt files are split on newlines without CSV parsing.
    """
    sep = "\t" if filename.endswith(".tsv") else ","
    if filename.endswith(".txt"):
        genes = "\n".join(g.strip() for g in content.strip().splitlines() if g.strip())
        return genes, None
    try:
        df = pd.read_csv(StringIO(content), sep=sep)
        df.columns = [c.strip().lower() for c in df.columns]
        if REQUIRED_CSV_COLS.issubset(df.columns):
            return "\n".join(df["gene"].dropna().astype(str).tolist()), df
        # Fallback: treat first column as gene list
        return "\n".join(df.iloc[:, 0].dropna().astype(str).tolist()), None
    except Exception:
        return "\n".join(g.strip() for g in content.strip().splitlines() if g.strip()), None


# ── Page sections ──────────────────────────────────────────────────────────

def _render_input_section() -> tuple[str, pd.DataFrame | None, bool]:
    """Render the shared file/text input widgets.

    Returns (gene_list, df_full_or_None, submit_button_clicked).
    """
    st.subheader("Input a gene set")
    st.caption(
        "Paste a plain gene list **or** upload/select a CSV/TSV with columns "
        "`gene`, `logfc`, `ave_expr`, `p_value`, `adj_p_value`, `comparison` "
        "to unlock the **Volcano Plot** and **MA Plot** tabs."
    )

    st.session_state.setdefault("uploader_counter", 0)
    st.session_state.setdefault("uploaded_file_names", [])

    gene_list: str = ""
    df_full: pd.DataFrame | None = None
    file_active = False

    col_input, col_genes = st.columns(2)

    with col_input:
        uploader_key = f"file_uploader_{st.session_state.uploader_counter}"
        uploaded_file = st.file_uploader(
            "Upload a file from your local drive",
            key=uploader_key,
            on_change=on_file_uploader_change,
            help="Plain .txt gene list or structured CSV/TSV with DE columns",
        )
        st.divider()

        exts = [".csv", ".tsv", ".txt"]
        data_files = [
            str(f).replace("../data/", "")
            for ext in exts
            for f in Path("../data").rglob(f"*{ext}")
        ]
        uploaded_opts = [
            f"[uploaded] {n}" for n in st.session_state.uploaded_file_names
        ]
        all_sel_opts = ["Select ..."] + uploaded_opts + data_files
        # Guard: reset if stored value is no longer in the option list
        if st.session_state.get("capsule_sel", "Select ...") not in all_sel_opts:
            st.session_state.capsule_sel = "Select ..."
        capsule_sel = st.selectbox(
            "Or select a file from the `data` folder (or a previously uploaded file)",
            all_sel_opts,
            key="capsule_sel",
            on_change=on_selectbox_change,
        )

        if capsule_sel != "Select ...":
            if capsule_sel.startswith("[uploaded] "):
                fname = capsule_sel[len("[uploaded] "):]
                raw = Path(f"../scratch/{fname}").read_text()
            else:
                fname = capsule_sel
                raw = Path(f"../data/{fname}").read_text()
            gene_list, df_full = try_parse_structured_csv(raw, fname)
            file_active = True
            st.session_state.text_input = gene_list
            if df_full is not None:
                st.success(
                    f"Structured CSV detected — {len(df_full)} genes loaded. "
                    "Volcano & MA Plot tabs are now active."
                )

        if uploaded_file is not None:
            dest = Path(f"{UPLOAD_FOLDER}/{uploaded_file.name}")
            dest.write_bytes(uploaded_file.getvalue())
            if uploaded_file.name not in st.session_state.uploaded_file_names:
                st.session_state.uploaded_file_names.append(uploaded_file.name)
            raw = uploaded_file.getvalue().decode("utf-8")
            gene_list, df_full = try_parse_structured_csv(raw, uploaded_file.name)
            file_active = True
            st.session_state.text_input = gene_list
            if df_full is not None:
                st.success(
                    f"Structured CSV detected — {len(df_full)} genes loaded. "
                    "Volcano & MA Plot tabs are now active."
                )

    with col_genes:
        st.text_area(
            label="Or paste a newline-separated gene list",
            key="text_input",
            height=400,
            help="One HGNC gene symbol per line (letters, digits, `-`, `_`; max 20 chars).",
        )
        # Only apply text-area input when no file source is active
        if not file_active:
            text = st.session_state.get("text_input", "")
            if text and re.match(HGNC_PATTERN, text):
                gene_list, df_full = text, None

        s_col, e_col, _ = st.columns([2, 4, 4])
        bt_submit = s_col.button("Submit")
        e_col.button("Input an example", on_click=input_example)

    return gene_list, df_full, bt_submit


def _render_gea_tab(gene_list: str, bt_submit: bool) -> None:
    st.subheader("Choose Gene Ontology Category")
    go_libraries = {
        "go_bp": st.checkbox("Biological Process", True),
        "go_cc": st.checkbox("Cellular Component"),
        "go_mf": st.checkbox("Molecular Function"),
    }
    go_names = {
        "go_bp": "Biological Process",
        "go_cc": "Cellular Component",
        "go_mf": "Molecular Function",
    }

    if not bt_submit:
        return

    genes = [g for g in gene_list.split("\n") if g.strip()]
    if not genes:
        st.error("Please input a newline-separated set of genes.")
        return
    if not any(go_libraries.values()):
        st.error("No GO libraries were selected for the analysis.")
        return

    n = len(genes)
    if n <= 10 or n >= 5000:
        size_label = "small" if n <= 10 else "large"
        s = "s" if n != 1 else ""
        st.warning(
            f"You've entered {n} gene{s} — this is a {size_label} list and may affect accuracy."
        )

    gene_list_str = "\n".join(genes)
    sub_gp, sub_pt = st.tabs(["g\\:Profiler", "Panther"])
    with sub_gp:
        for lib, enabled in go_libraries.items():
            if enabled:
                st.subheader(go_names[lib])
                render_results(gene_list_str, lib, Gprofiler)
    with sub_pt:
        for lib, enabled in go_libraries.items():
            if enabled:
                st.subheader(go_names[lib])
                render_results(gene_list_str, lib, Panther)


# ── Entry point ────────────────────────────────────────────────────────────

def main() -> None:
    st.sidebar.image(Image.open("static/CO_logo_135x72.png"), caption="Code Ocean")
    st.sidebar.title("Enrichment analysis")
    st.sidebar.write(
        "Submit a gene list to run enrichment analysis with g:Profiler and PANTHER. "
        "Upload a structured CSV with fold-change data to also unlock Volcano and MA plots."
    )

    gene_list, df_full, bt_submit = _render_input_section()
    st.divider()

    tab_gea, tab_volcano, tab_ma = st.tabs(
        ["Gene Enrichment Analysis", "Volcano Plot", "MA Plot"]
    )

    with tab_gea:
        _render_gea_tab(gene_list, bt_submit)

    with tab_volcano:
        if df_full is not None:
            render_volcano(df_full)
        else:
            st.info(_EMPTY_TAB)

    with tab_ma:
        if df_full is not None:
            render_ma(df_full)
        else:
            st.info(_EMPTY_TAB)


if __name__ == "__main__":
    main()
