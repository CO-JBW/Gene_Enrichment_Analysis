"""Volcano and MA plot rendering for the GEA Streamlit app."""
from __future__ import annotations

import numpy as np
import pandas as pd
import plotly.express as px
import streamlit as st


def render_volcano(df: pd.DataFrame) -> None:
    """Interactive Volcano Plot: log₂FC (x) vs −log₁₀(p-value) (y)."""
    df = df.copy()

    comparisons = df["comparison"].unique().tolist()
    if len(comparisons) > 1:
        sel = st.selectbox("Filter by comparison", ["All"] + comparisons, key="vol_comp")
        if sel != "All":
            df = df[df["comparison"] == sel]

    c1, c2 = st.columns(2)
    fc_thresh = c1.slider("log₂ FC threshold", 0.0, 5.0, 1.0, 0.1, key="vol_fc")
    pval_thresh = c2.slider(
        "Adjusted p-value threshold", 0.001, 0.5, 0.05, 0.001,
        format="%.3f", key="vol_pval",
    )

    df["neg_log10_pval"] = -np.log10(df["p_value"].clip(lower=1e-300))

    def _label(row: pd.Series) -> str:
        sig = row["adj_p_value"] < pval_thresh
        if sig and row["logfc"] > fc_thresh:
            return "Up-regulated"
        if sig and row["logfc"] < -fc_thresh:
            return "Down-regulated"
        return "Not significant"

    df["Regulation"] = df.apply(_label, axis=1)
    color_map = {
        "Up-regulated": "#d62728",
        "Down-regulated": "#1f77b4",
        "Not significant": "#bbbbbb",
    }

    fig = px.scatter(
        df, x="logfc", y="neg_log10_pval",
        color="Regulation", color_discrete_map=color_map,
        hover_data=["gene", "logfc", "p_value", "adj_p_value"],
        title="Volcano Plot",
        labels={"logfc": "log₂ Fold Change", "neg_log10_pval": "−log₁₀(p-value)"},
        opacity=0.7,
    )
    fig.add_vline(x=fc_thresh, line_dash="dot", line_color="black", opacity=0.5)
    fig.add_vline(x=-fc_thresh, line_dash="dot", line_color="black", opacity=0.5)
    fig.add_hline(
        y=-np.log10(pval_thresh), line_dash="dot", line_color="black", opacity=0.5
    )
    fig.update_layout(height=600, legend_title_text="")
    st.plotly_chart(fig, use_container_width=True)

    counts = df["Regulation"].value_counts()
    m1, m2, m3 = st.columns(3)
    m1.metric("Up-regulated", int(counts.get("Up-regulated", 0)))
    m2.metric("Down-regulated", int(counts.get("Down-regulated", 0)))
    m3.metric("Not significant", int(counts.get("Not significant", 0)))


def render_ma(df: pd.DataFrame) -> None:
    """Interactive MA Plot: average expression (A) vs log₂FC (M)."""
    df = df.copy()

    comparisons = df["comparison"].unique().tolist()
    if len(comparisons) > 1:
        sel = st.selectbox("Filter by comparison", ["All"] + comparisons, key="ma_comp")
        if sel != "All":
            df = df[df["comparison"] == sel]

    pval_thresh = st.slider(
        "Adjusted p-value threshold", 0.001, 0.5, 0.05, 0.001,
        format="%.3f", key="ma_pval",
    )
    df["Significance"] = df["adj_p_value"].apply(
        lambda p: "Significant" if p < pval_thresh else "Not significant"
    )
    color_map = {"Significant": "#d62728", "Not significant": "#bbbbbb"}

    fig = px.scatter(
        df, x="ave_expr", y="logfc",
        color="Significance", color_discrete_map=color_map,
        hover_data=["gene", "ave_expr", "logfc", "adj_p_value"],
        title="MA Plot",
        labels={"ave_expr": "Average Expression (A)", "logfc": "log₂ Fold Change (M)"},
        opacity=0.7,
    )
    fig.add_hline(y=0, line_dash="dash", line_color="black", opacity=0.5)
    fig.update_layout(height=600, legend_title_text="")
    st.plotly_chart(fig, use_container_width=True)

    n_sig = int((df["adj_p_value"] < pval_thresh).sum())
    st.caption(
        f"{n_sig} / {len(df)} genes significant at adj. p-value < {pval_thresh:.3f}"
    )
