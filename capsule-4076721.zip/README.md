[![Code Ocean Logo](images/CO_logo_135x72.png)](http://codeocean.com/product)

# GEA + Plots Streamlit App

An interactive Streamlit application for **Gene Enrichment Analysis (GEA)** backed by two widely-used external services — [g:Profiler](https://biit.cs.ut.ee/gprofiler/) and [PANTHER](https://pantherdb.org/). The app also supports **Volcano** and **MA plots** when structured differential expression data is provided.

> **Privacy notice:** This capsule submits gene lists to external APIs (g:Profiler and PANTHER). If you wish to keep your gene identifiers private, do not use this capsule with sensitive data.

---

## Features

| Tab | Description |
|-----|-------------|
| **Gene Enrichment Analysis** | Queries g:Profiler and PANTHER for GO term enrichment (Biological Process, Cellular Component, Molecular Function). Displays ranked results table and -log₁₀(p-value) bar chart. |
| **Volcano Plot** | Interactive scatter plot of log₂ fold change vs −log₁₀(p-value) with adjustable FC and p-value thresholds. Requires structured CSV/TSV input. |
| **MA Plot** | Average expression (A) vs log₂ fold change (M) scatter plot with significance highlighting. Requires structured CSV/TSV input. |

---

## Inputs

The app accepts gene data in two formats, which can be provided via file upload, selected from the `/data` folder, or pasted directly into the text area.

### Type 1 — Plain Gene List (`.txt`)

One HGNC gene symbol per line (letters, digits, `-`, `_`; max 20 characters per symbol). This format unlocks the **Gene Enrichment Analysis** tab only.

```
TP53
BRCA1
EGFR
MYC
```

> An example gene list is bundled at `code/static/example_gene_list.txt`. Click **"Input an example"** in the app to load it instantly.

**Validation rules:**
- Each symbol must match the pattern `[a-zA-Z][a-zA-Z0-9_-]{0,19}`.
- Lists with ≤ 10 or ≥ 5,000 genes will produce a warning, as very small or very large sets may reduce enrichment accuracy.

---

### Type 2 — Structured Differential Expression Table (`.csv` / `.tsv`)

A tabular file containing the following **required columns** unlocks all three tabs, including the **Volcano Plot** and **MA Plot**:

| Column | Type | Description |
|--------|------|-------------|
| `gene` | string | HGNC gene symbol |
| `logfc` | float | log₂ fold change |
| `ave_expr` | float | Average expression level across samples |
| `p_value` | float | Raw p-value |
| `adj_p_value` | float | Adjusted (FDR-corrected) p-value |
| `comparison` | string | Group comparison label (e.g. `"treated_vs_control"`) |

**Notes:**
- Column names are **case-insensitive** and trimmed of whitespace automatically.
- `.csv` files are parsed with `,` as the delimiter; `.tsv` files use `\t`.
- If the required columns are not all present, the app falls back to treating the first column as a plain gene list (GEA tab only).
- Uploaded files are temporarily stored in `/scratch` for the duration of the session.

---

## Outputs

This is an **interactive Streamlit application** — all outputs are rendered live within the app UI. No files are written to disk during normal interactive use.

### Gene Enrichment Analysis tab

| Output | Description |
|--------|-------------|
| **Results table** | Top 10 enriched GO terms ranked by p-value, showing term name/ID, gene overlap ratio, raw p-value, and FDR. Available for both g:Profiler and PANTHER sub-tabs. |
| **Bar chart** | Horizontal bar chart of the top 10 terms, with bar length proportional to −log₁₀(p-value). |

Results are shown separately for each selected GO category (Biological Process, Cellular Component, Molecular Function) and for each service (g:Profiler, PANTHER).

### Volcano Plot tab *(requires structured CSV/TSV input)*

| Output | Description |
|--------|-------------|
| **Scatter plot** | Each gene plotted as log₂ FC (x-axis) vs −log₁₀(p-value) (y-axis), coloured by regulation status. |
| **Threshold lines** | Dashed reference lines at the selected FC and adjusted p-value thresholds. |
| **Summary metrics** | Counts of up-regulated, down-regulated, and non-significant genes at the chosen thresholds. |

### MA Plot tab *(requires structured CSV/TSV input)*

| Output | Description |
|--------|-------------|
| **Scatter plot** | Each gene plotted as average expression / A (x-axis) vs log₂ FC / M (y-axis), coloured by significance. |
| **Reference line** | Dashed horizontal line at M = 0. |
| **Significance caption** | Count of significant genes at the selected adjusted p-value threshold. |

---

## How to Use

1. **Launch the app** via the Cloud Workstation (Streamlit IDE).
2. **Provide a gene set** using one of three methods:
   - Upload a file from your local drive.
   - Select a file from the attached `/data` folder using the dropdown.
   - Paste gene symbols directly into the text area.
   - Click **"Input an example"** to load the bundled example gene list.
3. **Choose GO categories** (Biological Process, Cellular Component, Molecular Function) in the GEA tab.
4. Click **Submit** to run the analysis.
5. Switch between the **g:Profiler** and **PANTHER** sub-tabs to compare results.
6. If a structured CSV/TSV was loaded, explore the **Volcano Plot** and **MA Plot** tabs with adjustable thresholds.

---

## Code Structure

```
code/
├── streamlit_app.py              # Main Streamlit application
├── plots.py                      # Volcano and MA plot rendering (Plotly)
├── enrichment/
│   ├── __init__.py
│   └── enrich.py                 # Enrich base class + Gprofiler and Panther implementations
├── static/
│   ├── CO_logo_135x72.png        # Sidebar logo
│   └── example_gene_list.txt     # Sample gene list for testing
├── .streamlit/
│   └── config.toml               # Streamlit theme/server configuration
├── run                           # Bash entrypoint for Reproducible Runs
└── README.md
```

---

## Dependencies

Key Python packages used:

- [`streamlit`](https://streamlit.io/) — web UI framework
- [`gprofiler-official`](https://pypi.org/project/gprofiler-official/) — g:Profiler Python client
- [`requests`](https://pypi.org/project/requests/) — HTTP calls to PANTHER REST API
- [`pandas`](https://pandas.pydata.org/) — data manipulation
- [`plotly`](https://plotly.com/python/) — interactive charts
- [`Pillow`](https://pillow.readthedocs.io/) — image rendering (sidebar logo)

---

## Author
- Alice Zheng
- Jacob Wolpe
- Maxim Kuleshov

[![Code Ocean Logo](images/CO_logo_68x36.png)](https://www.codeocean.com)
