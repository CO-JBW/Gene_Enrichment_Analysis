This [Code Ocean](https://codeocean.com) Compute Capsule will allow you to run and reproduce the results of [Copy of GEA + Plots Streamlit App](https://acmecorp-cfn-demo.codeocean.com/capsule/4076721/tree) on your local machine<sup>1</sup>. Follow the instructions below, or consult [our knowledge base](https://docs.codeocean.com/user-guide/compute-capsule-basics/managing-capsules/exporting-capsules-to-your-local-machine) for more information. Don't hesitate to reach out to [Support](mailto:support@codeocean.com) if you have any questions.

<sup>1</sup> You may need access to additional hardware and/or software licenses.

# Prerequisites

- [Docker Community Edition (CE)](https://www.docker.com/community-edition)

# Instructions

## Download attached Data Assets

In order to fetch the Data Asset(s) this Capsule depends on, download them into the Capsule's `data` folder:
* [de_test_data.csv](https://acmecorp-cfn-demo.codeocean.com/data-assets/eaa25793-fc02-47ac-9195-6e3ac4639b88) should be downloaded to `data/de_test`
* [de_test_2](https://acmecorp-cfn-demo.codeocean.com/data-assets/b3df4c89-8582-45de-9bd2-746b4d6bab93) should be downloaded to `data/de_test2`

## Log in to the Docker registry

In your terminal, execute the following command, providing your password or API key when prompted for it:
```shell
docker login -u jacob.wolpe@codeocean.com registry.acmecorp-cfn-demo.codeocean.com
```

## Run the Capsule to reproduce the results

In your terminal, navigate to the folder where you've extracted the Capsule and execute the following command, adjusting parameters as needed:
```shell
docker run --platform linux/amd64 --rm \
  --workdir /code \
  --volume "$PWD/code":/code \
  --volume "$PWD/data":/data \
  --volume "$PWD/results":/results \
  registry.acmecorp-cfn-demo.codeocean.com/capsule/1acacb95-1ecc-4a91-8cbe-12a68a909332 \
  bash run
```
